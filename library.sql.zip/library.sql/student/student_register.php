<?php
include('../db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password != $cpassword) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        $check = mysqli_query($conn, "SELECT * FROM students WHERE email='$email'");
        if (mysqli_num_rows($check) > 0) {
            echo "<script>alert('Email already registered');</script>";
        } else {
            $insert = "INSERT INTO students (name, email, mobile, password) VALUES ('$name', '$email', '$mobile', '$password')";
            if (mysqli_query($conn, $insert)) {
                echo "<script>alert('Registration successful!'); window.location.href='student_login.php';</script>";
            } else {
                echo "<script>alert('Registration failed');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Register</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f2f2f2;
            padding: 50px;
        }
        form {
            background: white;
            padding: 30px;
            width: 300px;
            margin: auto;
            box-shadow: 0 0 10px #aaa;
        }
        input {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color:rgb(56, 124, 110);
            color: white;
            border: none;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h2>Register</h2>
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email ID" required>
        <input type="text" name="mobile" placeholder="Mobile Number" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="cpassword" placeholder="Confirm Password" required>
        <button type="submit">Register</button>
        <p style="text-align:center;">Already registered? <a href="student_login.php">Login</a></p>
    </form>
    <p style="text-align:center; margin-top: 10px;">
    Already registered? <a href="student_login.php">Student Login</a>
</p>
</body>
</html>
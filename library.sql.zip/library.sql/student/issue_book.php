<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student = $_POST['student'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $book_id = $_POST['book_id'];
    $date = date("Y-m-d");

    $check = $conn->query("SELECT * FROM books WHERE id='$book_id' AND available=1");
    if ($check->num_rows > 0) {
        $conn->query("INSERT INTO issued_books (student_name, student_email, student_mobile, book_id, issue_date) 
                      VALUES ('$student', '$email', '$mobile', '$book_id', '$date')");
        $conn->query("UPDATE books SET available=0 WHERE id='$book_id'");
        echo "<script>alert('Book Issued'); window.location.href='issue_book.php';</script>";
    } else {
        echo "<script>alert('Book Not Available');</script>";
    }
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Issue Book</title>
    <style>
        body {
            font-family: Arial;
            background-image: url('Pixel.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            padding: 50px;
            color: #fff;
        }
        form {
            background: rgba(0, 0, 0, 0.6);
            padding: 30px;
            border-radius: 12px;
            width: 400px;
            margin: auto;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
        }
        input[type="submit"] {
            background: #28a745;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h2>Issue Book</h2>
        <label>Student Username:</label>
        <input type="text" name="student" required>

        <label>Student Email:</label>
        <input type="email" name="email" required>

        <label>Student Mobile:</label>
        <input type="text" name="mobile" required>

        <label>Select Book:</label>
        <select name="book_id" required>
            <?php
            $books = $conn->query("SELECT * FROM books WHERE available=1");
            while ($row = $books->fetch_assoc()) {
                echo "<option value='{$row['id']}'>{$row['title']} by {$row['author']}</option>";
            }
            ?>
        </select>

        <input type="submit" value="Issue Book">
    </form>
</body>
</html>
<?php
session_start();
include('../db.php'); // path adjust karo agar needed

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Agar password md5 se encrypt hai to ye line use karo:
    // $password = md5($password);

    $query = "SELECT * FROM students WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['student_id'] = $row['id'];
        $_SESSION['student_name'] = $row['name'];
        header("Location: student_dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid email or password'); window.location.href='student_login.php';</script>";
    }
}
?>

<!-- Student Login Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Student Login</title>
    <style>
        body {
            background-image: url('baground.jpg'); /* <-- Add your image in /student/images/ folder */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
        }

        .login-container {
            width: 350px;
            margin: 100px auto;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #fff;
        }

        h2, p {
            text-align: center;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        a {
            color: #00f7ff;
        }

        .welcome {
            text-align: center;
            font-size: 24px;
            margin-top: 30px;
            font-weight: bold;
            text-shadow: 2px 2px 5px black;
        }
    </style>
</head>
<body>

    <div class="welcome">Welcome to Library Management System</div>

    <div class="login-container">
        <h2>Student Login</h2>
        <form method="POST">
            Email: <input type="text" name="email" required><br>
            Password: <input type="password" name="password" required><br>
            <button type="submit">Login</button>
        </form>
        <p>Not registered yet? <a href="student_register.php">Register here</a></p>
    </div>

</body>
</html>
<?php
include '../db.php';

if (isset($_GET['return_id'])) {
    $id = $_GET['return_id'];

    // Get book_id from issued_books table before deleting
    $bookResult = mysqli_query($conn, "SELECT book_id FROM issued_books WHERE id = $id");
    $bookRow = mysqli_fetch_assoc($bookResult);
    $book_id = $bookRow['book_id'];

    // Delete the issued record
    mysqli_query($conn, "DELETE FROM issued_books WHERE id = $id");

    // Update the book as available
    mysqli_query($conn, "UPDATE books SET available = 1 WHERE id = $book_id");

    header("Location: return_book.php?success=1");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM issued_books");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Return Issued Books</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f4f4;
            padding: 30px;
        }

        .container {
            background: #fff;
            padding: 20px;
            max-width: 700px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background: #007BFF;
            color: white;
        }

        .btn {
            background-color: red;
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 5px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Return Issued Books</h2>
    <?php if (isset($_GET['success'])) echo "<p class='success'>Book returned successfully!</p>"; ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Student</th>
            <th>Book Title</th>
            <th>Issued On</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['student_name'] ?></td>
            <td><?= $row['book_id'] ?></td>
            <td><?= $row['issue_date'] ?></td>
            <td><a class="btn" href="?return_id=<?= $row['id'] ?>" onclick="return confirm('Return this book?')">Return</a></td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>
<?php
include '../db.php';
$result = mysqli_query($conn, "SELECT * FROM books");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View All Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('Pixel.jpg'); /* Change the path if needed */
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            color: #fff;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7);
            margin: 100px auto;
            padding: 30px;
            width: 80%;
            border-radius: 10px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            color: #000;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        h2 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>All Books</h2>
        <table>
            <tr>
                <th>Book ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Status</th> <!-- New Column -->
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['title'] ?></td>
                    <td><?= $row['author'] ?></td>
                    <td>
                        <?= $row['available'] == 1 ? 'Available' : 'Issued' ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
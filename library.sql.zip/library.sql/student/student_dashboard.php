<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: student_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('Pixel2.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: white;
            text-align: center;
        }
        .container {
            margin-top: 100px;
            background-color: rgba(18, 28, 29, 0.84);
            display: inline-block;
            padding: 40px;
            border-radius: 10px;
        }
        h1 {
            font-size: 30px;
            margin-bottom: 30px;
        }
        a {
            display: block;
            margin: 12px auto;
            color: #00aced;
            text-decoration: none;
            font-size: 18px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Student Dashboard</h1>
        <a href="view_books.php">View Books</a>
        <a href="issue_book.php">Issue Book</a>
        <a href="return_book.php">Return Book</a>
        <a href="student_logout.php">Logout</a>
    </div>
</body>
</html>
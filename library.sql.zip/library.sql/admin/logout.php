<?php
session_start();
session_destroy();
header("Location: login.php"); // ya index.php agar tumhara login page us naam se ho
exit();
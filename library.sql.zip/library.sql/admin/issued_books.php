 <?php
include '../db.php';
include 'sidebar.php';

$query = "SELECT ib.*, b.title, b.author FROM issued_books ib 
          JOIN books b ON ib.book_id = b.id";
$result = mysqli_query($conn, $query);
?>

<h3>Issued Books Report</h3>

<style>
    table {
        border-collapse: collapse;
        width: 90%;
        margin: 20px auto;
        font-family: Arial, sans-serif;
    }
    th, td {
        border: 1px solid #888;
        padding: 10px;
        text-align: center;
    }
    th {
        background-color: #4CAF50;
        color: white;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    h3 {
        text-align: center;
        margin-top: 20px;
        font-family: 'Segoe UI', sans-serif;
        color: #333;
    }
</style>

<table>
    <tr>
        <th>Student Name</th>
        <th>Book Title</th>
        <th>Author</th>
        <th>Issue Date</th>
        <th>Return Date</th>
    </tr>
    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['student_name']}</td>
                    <td>{$row['title']}</td>
                    <td>{$row['author']}</td>
                    <td>{$row['issue_date']}</td>
                    <td>" . ($row['return_date'] ?: 'Not Returned') . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No books have been issued yet.</td></tr>";
    }
    ?>
</table>
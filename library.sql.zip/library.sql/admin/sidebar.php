<div style="background-color: #f0f0f0; padding: 10px;">
    <h3>Admin Panel</h3>
    <ul style="list-style: none; padding-left: 0;">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="add_book.php">Add Book</a></li>
        <li><a href="view_books.php">View All Books</a></li>
        <li><a href="issued_books.php">Issued Book Report</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
<hr>
<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Convert to integer for safety

    // Delete query
    $query = "DELETE FROM books WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        // Redirect back to view page after deletion
        header("Location: view_books.php");
        exit;
    } else {
        echo "Error deleting book: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request. Book ID is missing.";
}
?>
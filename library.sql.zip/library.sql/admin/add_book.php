 <?php
include '../db.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);

    $query = "INSERT INTO books (title, author) VALUES ('$title', '$author')";
    if (mysqli_query($conn, $query)) {
        $message = "Book added successfully.";
    } else {
        $message = "Error adding book: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Book</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('Pixel1.jpg'); /* Make sure Pixel1.jpg is in same folder */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            background: rgba(94, 88, 88, 0.46);
            padding: 30px;
            border-radius: 10px;
            width: 350px;
            box-shadow: 0 0 15px rgba(14, 14, 14, 0.2);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background: #218838;
        }

        .message {
            text-align: center;
            margin-top: 10px;
            color: green;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Add New Book</h2>
        <form method="POST">
            <label>Title:</label>
            <input type="text" name="title" required>
            <label>Author:</label>
            <input type="text" name="author" required>
            <input type="submit" value="Add Book">
        </form>
        <p class="message"><?php echo $message; ?></p>
    </div>
</body>
</html>
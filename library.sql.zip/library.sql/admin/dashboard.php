 <?php
session_start();
include '../db.php';
include 'sidebar.php';

// Optional: Admin authentication check
// if (!isset($_SESSION['admin'])) {
//     header("Location: login.php");
//     exit();
// }

// Get all issued books
$issued = $conn->query("SELECT ib.*, b.title, b.author 
                        FROM issued_books ib 
                        JOIN books b ON ib.book_id = b.id 
                        ORDER BY ib.issue_date DESC");

// Get unique students
$students = $conn->query("SELECT DISTINCT student_name FROM issued_books");

// Total books
$total_books_result = $conn->query("SELECT COUNT(*) as total FROM books");
$total_books = ($total_books_result && $total_books_result->num_rows > 0) ? $total_books_result->fetch_assoc()['total'] : 0;

// Total issued books
$total_issued_result = $conn->query("SELECT COUNT(*) as issued FROM issued_books WHERE return_date IS NULL");
$total_issued = ($total_issued_result && $total_issued_result->num_rows > 0) ? $total_issued_result->fetch_assoc()['issued'] : 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background-color: #eef2f3;
            padding: 30px;
        }
        h2 {
            text-align: center;
        }
        .summary {
            text-align: center;
            margin-bottom: 30px;
        }
        .summary div {
            display: inline-block;
            margin: 0 30px;
            font-size: 18px;
            font-weight: bold;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            background: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
    <h2>Admin Dashboard</h2>

    <div class="summary">
        <div>Total Books: <?php echo $total_books; ?></div>
        <div>Issued Books: <?php echo $total_issued; ?></div>
        <div>Unique Students: <?php echo ($students ? $students->num_rows : 0); ?></div>
    </div>

    <h3 style="text-align:center;">Issued Books Report</h3>
    <table>
        <tr>
            <th>Student Username</th>
            <th>Book Title</th>
            <th>Author</th>
            <th>Issue Date</th>
            <th>Return Date</th>
        </tr>
        <?php 
        if ($issued && $issued->num_rows > 0) {
            while ($row = $issued->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['student_name']; ?></td>
                <td><?php echo $row['title']; ?></td>
                <td><?php echo $row['author']; ?></td>
                <td><?php echo $row['issue_date']; ?></td>
                <td><?php echo $row['return_date'] ? $row['return_date'] : 'Not Returned'; ?></td>
            </tr>
        <?php 
            }
        } else {
            echo "<tr><td colspan='5'>No books issued yet.</td></tr>";
        }
        ?>
    </table>
</body>
</html>